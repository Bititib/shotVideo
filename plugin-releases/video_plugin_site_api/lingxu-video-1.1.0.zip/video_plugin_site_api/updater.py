"""Pinned HTTPS releases; transactional program-only replacement. No credentials sent."""
import contextlib
import hashlib
import io
import json
import os
from pathlib import Path
import re
import sqlite3
import time
import urllib.request
import urllib.parse
import uuid
import zipfile

PLUGIN_ID = 'video_plugin_site_api'
UPDATE_ORIGIN = 'https://video.zhubo.asia'
MANIFEST_URL = UPDATE_ORIGIN + '/plugin-updates/video_plugin_site_api/latest.json'
FILES = ('main.py', 'updater.py', 'info.json', 'ui/index.html', '使用说明.txt')
MAX_ARCHIVE = 8 * 1024 * 1024

class UpdateError(Exception):
    pass

class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *args, **kwargs):
        return None

def version(value):
    if not isinstance(value, str) or not re.fullmatch(r'(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)', value):
        raise UpdateError('发布版本号无效')
    return tuple(map(int, value.split('.')))

def atomic(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + '.' + uuid.uuid4().hex + '.tmp')
    try:
        with temp.open('xb') as stream:
            stream.write(data); stream.flush(); os.fsync(stream.fileno())
        os.replace(temp, path)
    finally:
        temp.unlink(missing_ok=True)

def write_json(path, data):
    atomic(path, json.dumps(data, ensure_ascii=False).encode('utf-8'))

@contextlib.contextmanager
def file_lock(path):
    path.parent.mkdir(parents=True, exist_ok=True)
    f = path.open('a+b')
    try:
        f.seek(0, 2)
        if not f.tell(): f.write(b'0'); f.flush()
        f.seek(0)
        if os.name == 'nt':
            import msvcrt
            msvcrt.locking(f.fileno(), msvcrt.LK_NBLCK, 1)
        else:
            import fcntl
            fcntl.flock(f, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError:
        f.close()
        raise UpdateError('插件正在工作或更新，请稍后再试') from None
    try:
        yield
    finally:
        f.close()

def installed_version(root):
    value = json.loads((root / 'info.json').read_text('utf-8'))['version']
    version(value)
    return value

def restore(root, state, entry):
    # Journal cannot name arbitrary paths. Verify every backup before writing any file.
    name = entry.get('backup', '')
    if not re.fullmatch(r'[a-f0-9]{32}', name): raise UpdateError('更新备份记录无效')
    backup = state / 'updates' / name
    contents = {}
    for file in FILES:
        data = (backup / file).read_bytes()
        if hashlib.sha256(data).hexdigest() != entry['hashes'][file]: raise UpdateError('更新备份校验失败')
        contents[file] = data
    for file in FILES: atomic(root / file, contents[file])

def recover_interrupted(root, state):
    journal = state / 'update-pending.json'
    if journal.exists():
        restore(root, state, json.loads(journal.read_text('utf-8')))
        journal.unlink()

@contextlib.contextmanager
def activity(root, state, running_version):
    # The gate closes the check/start race; leases stay OS-locked during generation/recovery.
    lease = state / 'operations' / (uuid.uuid4().hex + '.lock')
    with contextlib.ExitStack() as stack:
        with file_lock(state / 'update-gate.lock'):
            recover_interrupted(root, state)
            if installed_version(root) != running_version:
                raise UpdateError('插件已升级，请重启字字动画后再生成或取回视频')
            stack.enter_context(file_lock(lease))
        try: yield
        finally:
            stack.close()
            lease.unlink(missing_ok=True)

def assert_idle(state):
    for lease in (state / 'operations').glob('*.lock'):
        with file_lock(lease): pass
        lease.unlink(missing_ok=True)
    db_path = state / 'tasks.sqlite3'
    if db_path.exists():
        # Read only. Never migrate or rewrite a task ledger during installation.
        with contextlib.closing(sqlite3.connect(db_path.as_uri() + '?mode=ro', uri=True)) as db:
            count = db.execute("SELECT COUNT(*) FROM tasks WHERE state NOT IN ('downloaded','failed')").fetchone()[0]
        if count: raise UpdateError(f'还有 {count} 条处理中、待取回或待核实任务，请先在任务记录处理，再升级')

def download(url, limit):
    parsed = urllib.parse.urlsplit(url)
    if parsed.scheme != 'https' or parsed.netloc != 'video.zhubo.asia' or parsed.query or parsed.fragment or not parsed.path.startswith('/plugin-updates/video_plugin_site_api/'):
        raise UpdateError('更新地址不属于官方发布目录')
    opener = urllib.request.build_opener(NoRedirect())
    request = urllib.request.Request(url, headers={'Accept': 'application/json, application/zip', 'User-Agent': 'LingxuPluginUpdater/1'})
    try:
        with opener.open(request, timeout=30) as response:
            data = response.read(limit + 1)
    except Exception:
        raise UpdateError('暂时无法连接插件更新服务，现有插件仍可使用，请稍后重试') from None
    if len(data) > limit: raise UpdateError('更新文件超过大小限制')
    return data

def manifest():
    try: data = json.loads(download(MANIFEST_URL, 65536))
    except (ValueError, UnicodeError): raise UpdateError('更新清单格式无效') from None
    if not isinstance(data, dict) or data.get('schema_version') != 1 or data.get('plugin_id') != PLUGIN_ID:
        raise UpdateError('更新清单不适用于此插件')
    version(data.get('version'))
    if data.get('min_updater', 1) != 1: raise UpdateError('此版本需要手动安装，请下载网站提供的完整插件包')
    if not isinstance(data.get('sha256'), str) or not re.fullmatch(r'[a-f0-9]{64}', data['sha256']): raise UpdateError('缺少安装包校验信息')
    size = data.get('size')
    if type(size) is not int or not 0 < size <= MAX_ARCHIVE: raise UpdateError('安装包大小无效')
    relative = data.get('archive', '')
    if not re.fullmatch(r'/plugin-updates/video_plugin_site_api/[A-Za-z0-9._-]+\.zip', relative): raise UpdateError('安装包路径无效')
    if not isinstance(data.get('notes', ''), str): raise UpdateError('更新说明格式无效')
    return data

def check(root, state, running_version, manual=False):
    with file_lock(state / 'update-gate.lock'):
        recover_interrupted(root, state)
        current = installed_version(root)
    cache = state / 'update-check.json'
    info = None
    if not manual and cache.exists():
        try:
            saved = json.loads(cache.read_text('utf-8'))
            if 0 <= time.time() - saved['checked'] < 21600: info = saved['manifest']
        except (ValueError, KeyError, TypeError): pass
    if info is None:
        info = manifest()
        write_json(cache, {'checked': time.time(), 'manifest': info})
    return {'ok': True, 'current_version': current, 'latest_version': info['version'],
            'available': version(info['version']) > version(current), 'notes': info.get('notes', '')[:8000],
            'restart_required': current != running_version,
            'can_rollback': (state / 'update-previous.json').exists()}

def unpack(raw, info):
    if len(raw) != info['size'] or hashlib.sha256(raw).hexdigest() != info['sha256']:
        raise UpdateError('安装包完整性校验失败，未修改现有插件')
    contents = {}
    try:
        with zipfile.ZipFile(io.BytesIO(raw)) as archive:
            expected = {PLUGIN_ID + '/' + f for f in FILES}
            if len(archive.infolist()) != len(FILES) or set(archive.namelist()) != expected:
                raise UpdateError('安装包文件清单不符，未修改现有插件')
            for item in archive.infolist():
                if item.file_size > 4 * 1024 * 1024 or (item.external_attr >> 16) & 0o170000 == 0o120000:
                    raise UpdateError('安装包包含不支持的文件')
                contents[item.filename[len(PLUGIN_ID)+1:]] = archive.read(item)
        metadata = json.loads(contents['info.json'])
        if metadata['version'] != info['version'] or metadata.get('type') != 'video' or metadata.get('api_version') != 2:
            raise UpdateError('安装包版本或宿主接口不匹配')
        for name in ('main.py', 'updater.py'): compile(contents[name], name, 'exec')
    except (ValueError, KeyError, SyntaxError, zipfile.BadZipFile, UnicodeError):
        raise UpdateError('安装包内容校验失败，未修改现有插件') from None
    return contents

def install(root, state, running_version, expected_version):
    with file_lock(state / 'update-gate.lock'):
        recover_interrupted(root, state)
        if installed_version(root) != running_version: raise UpdateError('请先重启字字动画，使已安装版本生效')
        assert_idle(state)
        info = manifest()  # Never trust a cached manifest or paths supplied by the UI.
        if info['version'] != expected_version: raise UpdateError('网站版本已变化，请重新检查更新后点击升级')
        if version(info['version']) <= version(installed_version(root)): raise UpdateError('当前已经是此版本或更新版本')
        contents = unpack(download(UPDATE_ORIGIN + info['archive'], MAX_ARCHIVE), info)
        backup = uuid.uuid4().hex
        entry = {'backup': backup, 'version': installed_version(root), 'hashes': {}}
        for file in FILES:
            original = (root / file).read_bytes()
            atomic(state / 'updates' / backup / file, original)
            entry['hashes'][file] = hashlib.sha256(original).hexdigest()
        write_json(state / 'update-pending.json', entry)
        try:
            for file in FILES: atomic(root / file, contents[file])
            write_json(state / 'update-previous.json', entry)
            (state / 'update-pending.json').unlink()
        except Exception:
            recover_interrupted(root, state)
            raise UpdateError('升级失败，已恢复原插件；配置与任务记录保留') from None
        return {'ok': True, 'restart_required': True, 'current_version': info['version'],
                'message': '升级已安装，配置和任务记录已保留。请重启字字动画使新版生效。'}

def rollback(root, state):
    with file_lock(state / 'update-gate.lock'):
        recover_interrupted(root, state)
        assert_idle(state)
        previous = state / 'update-previous.json'
        if not previous.exists(): raise UpdateError('没有可回退的旧版备份')
        entry = json.loads(previous.read_text('utf-8'))
        write_json(state / 'update-pending.json', entry)
        recover_interrupted(root, state)
        previous.unlink()
        return {'ok': True, 'restart_required': True, 'current_version': entry['version'],
                'message': '已回退上一版，配置和任务记录保留。请重启字字动画。'}
