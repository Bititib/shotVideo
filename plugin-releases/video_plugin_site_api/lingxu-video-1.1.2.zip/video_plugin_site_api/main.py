"""TypeTale 9.1.50 video plugin. Uses only the Python standard library."""
import contextlib
import base64
import hashlib
import json
import math
import mimetypes
import os
from pathlib import Path
import re
import sqlite3
import sys
import tempfile
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
import importlib.util

VERSION = "1.1.2"
PLUGIN_ROOT = Path(__file__).resolve().parent
_update_spec = importlib.util.spec_from_file_location('lingxu_updater', PLUGIN_ROOT / 'updater.py')
updater = importlib.util.module_from_spec(_update_spec)
_update_spec.loader.exec_module(updater)
DEFAULTS = dict(base_url="https://video.zhubo.asia", api_key="", model="", seconds="6", ratio="16:9",
                resolution="720p", input_mode="references", poll_interval=5,
                wait_minutes=45, request_timeout=180, model_family="")
STATE_DIR = Path(__file__).resolve().parent / ".state"


class PluginError(Exception):
    pass


class ApiError(PluginError):
    def __init__(self, message, status):
        super().__init__(message)
        self.status = status


def get_info():
    return dict(name="灵序 AI 视频插件", description="连接灵序 AI 网站，生成视频并自动取回结果", version=VERSION,
                images_per_batch=1)


def get_params():
    params = DEFAULTS.copy()
    try:
        if "plugin_utils" not in sys.modules:
            for parent in Path(__file__).resolve().parents:
                candidates = (parent / "_internal" / "plugins", parent / "plugins")
                for candidate in candidates:
                    if (candidate / "plugin_utils.py").is_file() and str(candidate) not in sys.path:
                        sys.path.append(str(candidate))
        from plugin_utils import load_plugin_config
        params.update(load_plugin_config(__file__))
    except ImportError:
        config = Path(__file__).with_name("config.json")
        if config.exists():
            params.update(json.loads(config.read_text(encoding="utf-8")))
    return params


def redact(value, key=""):
    text = str(value)
    if key:
        text = text.replace(key, "[密钥已隐藏]")
    text = re.sub(r"sk-[A-Za-z0-9_-]+", "[密钥已隐藏]", text)
    text = re.sub(r"https?://[^\s<>\"']+", "[链接已隐藏]", text)
    return text[:1000]


def reason(body):
    if not isinstance(body, dict):
        return "服务器未提供结构化错误原因"
    parts = []
    for field in ("error_message", "error", "message", "failure_reason", "code", "type"):
        value = body.get(field)
        if isinstance(value, dict):
            value = reason(value)
        if isinstance(value, (str, int)) and str(value) not in parts:
            parts.append(str(value))
    return "；".join(parts) or "服务器未提供具体原因"


def base_url(value):
    value = str(value).strip().rstrip("/")
    parsed = urllib.parse.urlsplit(value)
    if parsed.scheme not in ("http", "https") or not parsed.hostname or parsed.username or parsed.password or parsed.query or parsed.fragment:
        raise PluginError("请填写完整网站地址，例如 https://你的网站域名，可带 /v1")
    return value if value.endswith("/v1") else value + "/v1"


def bounded(value, low, high, name):
    try:
        result = float(value)
    except (TypeError, ValueError):
        raise PluginError(name + "必须为数字")
    if not math.isfinite(result) or not low <= result <= high:
        raise PluginError(f"{name}必须在 {low}–{high} 之间")
    return result


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def video_spec(record):
    """Normalize the website's public /api/video/models contract, not price keys."""
    limits = record.get("routingLimits") or {}
    if not isinstance(limits, dict):
        limits = {}
    def strings(value):
        return list(dict.fromkeys(v.strip() for v in value if isinstance(v, str) and v.strip())) if isinstance(value, list) else []
    def numbers(value):
        return sorted(set(float(v) for v in value if isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(v) and 0 < v <= 3600)) if isinstance(value, list) else []
    duration = None
    rule = limits.get("duration") or {}
    if isinstance(rule, dict):
        mode = rule.get("mode")
        if mode == "options" and numbers(rule.get("values")):
            duration = {"mode": "options", "values": numbers(rule["values"])}
        elif mode == "fixed" and numbers([rule.get("min")]):
            duration = {"mode": "options", "values": numbers([rule["min"]])}
        elif mode == "range":
            low, high, step = rule.get("min"), rule.get("max"), rule.get("step")
            if all(isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(v) for v in (low, high, step)) and 0 < low <= high <= 3600 and step > 0:
                duration = {"mode": "range", "min": low, "max": high, "step": step}
    if duration is None and numbers(record.get("allowedSeconds")):
        duration = {"mode": "options", "values": numbers(record["allowedSeconds"])}
    rates = record.get("rates")
    resolutions = strings(limits.get("resolutions")) or (strings(list(rates)) if isinstance(rates, dict) else [])
    ratios = strings(limits.get("ratios"))
    media = {k: v for k, v in limits.items() if k in ("maxImages", "maxVideos", "maxAudios", "minImages", "maxOutputs")
             and isinstance(v, int) and not isinstance(v, bool) and 0 <= v <= 10000}
    for key in ("firstFrame", "lastFrame", "framesExclusive"):
        if isinstance(limits.get(key), bool):
            media[key] = limits[key]
    if record.get("requireRef") is True and "minImages" not in media:
        media["minImages"] = 1
    parameters, errors = parameter_schema(record.get("parameterSchema"))
    labels = record.get("parameterEnumLabels", {})
    for field in parameters:
        names = labels.get(field["key"]) if isinstance(labels, dict) else None
        if isinstance(names, list) and len(names) == len(field.get("enum", [])) and all(isinstance(s, str) and len(s) <= 120 for s in names):
            field["enumLabels"] = names
    return {"duration": duration, "resolutions": resolutions, "ratios": ratios,
            "media": media, "parameters": parameters, "schema_errors": errors,
            "parameter_note": str(record.get("parameterNote") or "")[:2000],
            "schema_version": record.get("capabilityVersion")} if duration or resolutions or ratios or media or parameters or errors or record.get("capabilityVersion") else None


RESERVED_FIELDS = set("model prompt seconds duration video_length ratio aspect_ratio resolution api_key base_url authorization token password headers url endpoint method image images image_urls video videos video_urls audio audios audio_urls first_frame first_frame_url last_frame last_frame_url end_frame_url n count batch_size __proto__ constructor prototype".split())


def parameter_schema(schema):
    """A bounded JSON Schema subset for flat, typed generation parameters. Never execute metadata."""
    if schema is None:
        return [], []
    if not isinstance(schema, dict) or schema.get("type") != "object" or not isinstance(schema.get("properties"), dict):
        return [], ["网站特殊参数定义格式不受支持"]
    if len(schema["properties"]) > 48:
        return [], ["网站特殊参数数量超过支持上限"]
    required = schema.get("required", [])
    if not isinstance(required, list) or not all(isinstance(k, str) for k in required):
        return [], ["网站必填参数定义无效"]
    fields, errors = [], []
    supported = {"type", "title", "description", "enum", "default", "minimum", "maximum", "multipleOf", "minLength", "maxLength", "readOnly"}
    for key, rule in schema["properties"].items():
        audio_switch = key == "audio" and isinstance(rule, dict) and rule.get("type") == "boolean"
        if not isinstance(key, str) or not re.fullmatch(r"[A-Za-z][A-Za-z0-9_]{0,63}", key) or (key.lower() in RESERVED_FIELDS and not audio_switch):
            errors.append("网站特殊参数包含保留或无效字段")
            continue
        if not isinstance(rule, dict) or rule.get("type") not in ("string", "integer", "number", "boolean") or set(rule) - supported:
            errors.append(f"参数 {key} 的定义暂不受支持")
            continue
        if rule.get("readOnly"):
            if key in required:
                errors.append(f"必填参数 {key} 不能设为只读")
            continue
        field = {"key": key, "type": rule["type"], "title": str(rule.get("title") or key)[:120],
                 "description": str(rule.get("description") or "")[:2000], "required": key in required}
        valid = True
        for limit in ("minimum", "maximum", "multipleOf", "minLength", "maxLength"):
            if limit in rule:
                v = rule[limit]
                if not isinstance(v, (int, float)) or isinstance(v, bool) or not math.isfinite(v) or (limit == "multipleOf" and v <= 0) or (limit in ("minLength", "maxLength") and (not isinstance(v, int) or v < 0)):
                    valid = False
                else:
                    field[limit] = v
        if "enum" in rule:
            choices = rule["enum"]
            if not isinstance(choices, list) or not choices or len(choices) > 200 or any(not parameter_type(v, field["type"]) for v in choices):
                valid = False
            else:
                field["enum"] = choices
        if "default" in rule and parameter_type(rule["default"], field["type"]):
            field["default"] = rule["default"]
        if not valid:
            errors.append(f"参数 {key} 的取值约束无效")
        else:
            fields.append(field)
    for key in required:
        if key not in schema["properties"]:
            errors.append(f"缺少必填参数 {key} 的定义")
    return fields, errors


def parameter_type(value, kind):
    if kind == "string":
        return isinstance(value, str)
    if kind == "boolean":
        return isinstance(value, bool)
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value) and (kind != "integer" or float(value).is_integer())


def special_values(params):
    bundle = params.get("special_parameters") or {}
    if not isinstance(bundle, dict) or bundle.get("model") != params.get("model"):
        return {}
    scope = hashlib.sha256((base_url(params.get("base_url") or DEFAULTS["base_url"]) + "\0" + str(params.get("api_key", "")).strip()).encode()).hexdigest()
    if bundle.get("scope") != scope:
        return {}
    values = bundle.get("values") or {}
    if not isinstance(values, dict) or len(values) > 48:
        raise PluginError("特殊参数格式无效，请在插件中重新设置")
    for key, value in values.items():
        audio_switch = key == "audio" and isinstance(value, bool)
        if not isinstance(key, str) or not re.fullmatch(r"[A-Za-z][A-Za-z0-9_]{0,63}", key) or (key.lower() in RESERVED_FIELDS and not audio_switch) or not any(parameter_type(value, k) for k in ("string", "number", "boolean")):
            raise PluginError("特殊参数字段或类型无效")
        if isinstance(value, str) and len(value) > 20000:
            raise PluginError(f"特殊参数 {key} 文本过长")
    return values


def validate_capabilities(params, spec, payload, media):
    spec = spec or {}
    if spec.get("schema_errors"):
        raise PluginError("；".join(spec["schema_errors"]) + "；未创建视频任务")
    values = special_values(params)
    fields = {f["key"]: f for f in spec.get("parameters", [])}
    if set(values) - set(fields):
        raise PluginError("已保存的特殊参数已不受此模型支持，请在插件中清除失效参数；未创建视频任务")
    for key, field in fields.items():
        if key not in values:
            if field.get("required"):
                raise PluginError(f"请填写必填参数：{field['title']}；未创建视频任务")
            continue
        v = values[key]
        valid = parameter_type(v, field["type"])
        if "enum" in field:
            valid = valid and any(type(v) is type(x) and v == x or not isinstance(v, bool) and not isinstance(x, bool) and isinstance(v, (int, float)) and isinstance(x, (int, float)) and v == x for x in field["enum"])
        if valid and field["type"] in ("number", "integer"):
            valid = v >= field.get("minimum", -math.inf) and v <= field.get("maximum", math.inf)
            if field.get("multipleOf"):
                valid = valid and math.isclose(v / field["multipleOf"], round(v / field["multipleOf"]), abs_tol=1e-8)
        if valid and field["type"] == "string":
            valid = field.get("minLength", 0) <= len(v) <= field.get("maxLength", 20000)
        if not valid:
            raise PluginError(f"参数 {field['title']} 不符合网站当前规格，请重新设置；未创建视频任务")
    limits = spec.get("media") or {}
    first, last = bool(payload.get("first_frame_url")), bool(payload.get("last_frame_url"))
    for used, field, label in ((first, "firstFrame", "首帧"), (last, "lastFrame", "尾帧")):
        if used and limits.get(field) is not True:
            raise PluginError(f"网站未确认此模型支持独立{label}，请更换参考方式；未创建视频任务")
    counts = {kind: len(media.get(kind, [])) + len(payload.get(kind + "_urls", [])) for kind in ("image", "video", "audio")}
    if limits.get("framesExclusive") is True and (first or last) and any(counts.values()):
        raise PluginError("此模型的首尾帧与普通参考素材不能混用；未创建视频任务")
    counts["image"] += int(first) + int(last)
    for kind, field, title in (("image", "maxImages", "图片"), ("video", "maxVideos", "视频"), ("audio", "maxAudios", "音频")):
        if field in limits and counts[kind] > limits[field]:
            raise PluginError(f"此模型最多支持 {limits[field]} 个{title}素材，当前 {counts[kind]} 个；未创建视频任务")
    if counts["image"] < limits.get("minImages", 0):
        raise PluginError(f"此模型至少需要 {limits['minImages']} 张图片；未创建视频任务")


def validate_selected_spec(params, client):
    spec = params.get("_model_spec")
    if not isinstance(spec, dict) or spec.get("model") != params.get("model") or spec.get("scope") != client.scope:
        return
    duration = spec.get("duration") or {}
    if duration:
        try:
            seconds = float(params.get("seconds", ""))
            if duration["mode"] == "options":
                valid = seconds in duration["values"]
            else:
                step = (seconds - duration["min"]) / duration["step"]
                valid = duration["min"] <= seconds <= duration["max"] and math.isclose(step, round(step), abs_tol=1e-8)
        except (KeyError, TypeError, ValueError, ZeroDivisionError, OverflowError):
            valid = False
        if not valid:
            raise PluginError("当前时长不符合此模型的规格，请在插件设置中重新选择时长；未创建视频任务")
    for key, field, title in (("resolutions", "resolution", "分辨率"), ("ratios", "ratio", "画面比例")):
        values = spec.get(key)
        if values and str(params.get(field, "")).lower() not in [str(v).lower() for v in values]:
            raise PluginError(f"当前{title}不符合此模型的规格，请在插件设置中重新选择；未创建视频任务")


def read_catalog(client):
    models = client.request("GET", "/models").get("data")
    prices = client.request("GET", "/pricing").get("data")
    if not isinstance(models, list) or not isinstance(prices, list):
        raise PluginError("网站模型或价格列表格式异常，请稍后刷新；未创建视频任务")
    by_id = {row["model"]: row for row in prices
             if isinstance(row, dict) and isinstance(row.get("model"), str)
             and isinstance(row.get("capabilities"), list) and "video" in row["capabilities"]}
    warning = ""
    try:
        metadata = client.public_video_metadata()
    except Exception:
        metadata = {}
        warning = "模型已连接，但暂未取得规格；时长和分辨率可手动填写。"
    rows = []
    seen = set()
    for model in models:
        if not isinstance(model, dict) or not isinstance(model.get("id"), str):
            continue
        model_id = model["id"]
        canonical = model.get("canonical_id")
        canonical = canonical if isinstance(canonical, str) else None
        price = by_id.get(model_id) or by_id.get(canonical)
        if price is None or model_id in seen:
            continue
        seen.add(model_id)
        item = metadata.get(model_id) or metadata.get(canonical) or {}
        spec = video_spec(model) if model.get("capabilityVersion") else item.get("spec")
        if model.get('capabilityVersion') and spec and item.get('spec'):
            for field in ('duration', 'resolutions', 'ratios'):
                if not spec.get(field): spec[field] = item['spec'].get(field)
        rows.append({"id": model_id, "price": price,
                     "spec": {**spec, "model": model_id, "scope": client.scope} if spec else None,
                     "description": model.get("description") or item.get("description", ""),
                     "available": model.get("available") is not False and item.get("available") is not False})
    return {"ok": True, "models": rows, "spec_warning": warning,
            "message": f"同步成功，{len(rows)} 个有视频计费配置的模型"}


def validate_live_model(params, client, payload=None, media=None):
    """Recheck before each new paid request; never gate recovery of an existing task."""
    try:
        catalog = read_catalog(client)
    except Exception as exc:
        raise PluginError("暂时无法确认网站最新模型，请稍后重试；未创建视频任务。" + str(exc)) from None
    selected = next((row for row in catalog["models"] if row["id"] == params.get("model")), None)
    if selected is None or selected.get("available") is False:
        raise PluginError("当前模型已下线、被停用或不再对当前 API Key 开放，请打开插件重新选择模型；未创建视频任务")
    fresh = dict(params)
    # Prefer live specifications. During a metadata outage, keep scoped saved validation.
    if selected.get("spec") or not catalog["spec_warning"]:
        fresh["_model_spec"] = selected.get("spec")
    validate_selected_spec(fresh, client)
    if payload is not None:
        # Extra fields require fresh confirmation; cached declarations cannot authorize a paid request.
        if catalog['spec_warning'] and not selected.get('spec') and (special_values(params) or payload.get('first_frame_url') or payload.get('last_frame_url')):
            raise PluginError('暂时无法确认网站特殊参数或首尾帧规格，请稍后重试；未创建视频任务')
        validate_capabilities(params, selected.get('spec'), payload, media)


class Client:
    def __init__(self, params):
        self.base = base_url(params.get("base_url") or DEFAULTS["base_url"])
        self.key = str(params.get("api_key", "")).strip()
        if not self.key or "\n" in self.key or "\r" in self.key:
            raise PluginError("请在插件设置中填写有效的网站 API Key")
        self.timeout = bounded(params.get("request_timeout", 180), 10, 900, "请求超时秒数")
        self.opener = urllib.request.build_opener(NoRedirect())
        self.scope = hashlib.sha256((self.base + "\0" + self.key).encode()).hexdigest()

    def public_video_metadata(self):
        # Public metadata uses no API key; never forward credentials or redirects.
        url = self.base[:-3] + "/api/video/models"
        req = urllib.request.Request(url, headers={"Accept": "application/json"})
        with self.opener.open(req, timeout=min(self.timeout, 15)) as response:
            data = json.loads(response.read(4 * 1024 * 1024))
        if not isinstance(data, list):
            raise ValueError("视频规格响应不是列表")
        return {key: {"spec": video_spec(row), "available": row.get("available") is not False,
                            "description": row["description"].strip() if isinstance(row.get("description"), str) else ""}
                for row in data if isinstance(row, dict) and isinstance(row.get("id"), str)
                for key in {row['id'], row.get('canonical_id') or row['id']}}

    def request(self, method, endpoint, data=None, content_type=None, length=None):
        headers = {"Authorization": "Bearer " + self.key, "Accept": "application/json"}
        if isinstance(data, dict):
            data = json.dumps(data, ensure_ascii=False).encode("utf-8")
            content_type = "application/json"
        if content_type:
            headers["Content-Type"] = content_type
        if length is not None:
            headers["Content-Length"] = str(length)
        req = urllib.request.Request(self.base + endpoint, data=data, headers=headers, method=method)
        try:
            with self.opener.open(req, timeout=self.timeout) as response:
                raw = response.read(4 * 1024 * 1024)
                result = json.loads(raw)
                if not isinstance(result, dict):
                    raise ValueError("响应不是对象")
                return result
        except urllib.error.HTTPError as exc:
            try:
                detail = reason(json.loads(exc.read(65536)))
            except (ValueError, UnicodeError):
                detail = "服务器返回非 JSON 内容"
            finally:
                exc.close()
            raise ApiError(redact(f"{method} {endpoint}：HTTP {exc.code}，{detail}", self.key), exc.code) from None
        except (OSError, ValueError, urllib.error.URLError) as exc:
            raise PluginError(redact(f"{method} {endpoint}：网络或响应异常（{type(exc).__name__}）", self.key)) from None

    def submit(self, payload, media):
        if not any(media.values()):
            return self.request("POST", "/videos", payload)
        boundary = "TypeTale" + uuid.uuid4().hex
        # Spool multipart data to disk: large references do not fill RAM.
        with tempfile.TemporaryFile() as body:
            def field(name, value):
                body.write((f'--{boundary}\r\nContent-Disposition: form-data; name="{name}"\r\n\r\n{value}\r\n').encode())
            for name, value in payload.items():
                if isinstance(value, list):
                    # Express/multer parses repeated [] fields into real arrays.
                    for item in value:
                        field(name + "[]", item)
                else:
                    field(name, json.dumps(value, ensure_ascii=False) if isinstance(value, (dict, bool)) else value)
            for kind, paths in media.items():
                for index, path in enumerate(paths):
                    suffix = Path(path).suffix.lower()
                    if not re.fullmatch(r"\.[a-z0-9]{1,8}", suffix):
                        raise PluginError("参考文件扩展名无效")
                    mime = mimetypes.guess_type(path)[0] or "application/octet-stream"
                    body.write((f'--{boundary}\r\nContent-Disposition: form-data; name="{kind}"; filename="ref_{index}{suffix}"\r\nContent-Type: {mime}\r\n\r\n').encode())
                    with open(path, "rb") as source:
                        while True:
                            chunk = source.read(1024 * 1024)
                            if not chunk:
                                break
                            body.write(chunk)
                    body.write(b"\r\n")
            body.write(f"--{boundary}--\r\n".encode())
            length = body.tell()
            body.seek(0)
            return self.request("POST", "/videos", body, "multipart/form-data; boundary=" + boundary, length)

    def query(self, task_id):
        return self.request("GET", "/videos/" + urllib.parse.quote(task_id, safe=""))

    def download(self, task_id, output):
        # Download through the website's documented authenticated endpoint.
        url = self.base + "/videos/" + urllib.parse.quote(task_id, safe="") + "/content"
        partial = str(output) + "." + uuid.uuid4().hex + ".part"
        deadline = time.monotonic() + 900
        try:
            for hop in range(6):
                parsed = urllib.parse.urlsplit(url)
                if parsed.scheme not in ("https", "http") or parsed.username or parsed.password:
                    raise PluginError("下载地址无效")
                origin = lambda u: (u.scheme, u.hostname, u.port or (443 if u.scheme == "https" else 80))
                same_origin = origin(parsed) == origin(urllib.parse.urlsplit(self.base))
                if not same_origin and parsed.scheme != "https":
                    raise PluginError("拒绝跳转到不安全的下载地址")
                headers = {"Authorization": "Bearer " + self.key} if same_origin else {}
                req = urllib.request.Request(url, headers=headers)
                try:
                    response = self.opener.open(req, timeout=min(self.timeout, 120))
                except urllib.error.HTTPError as exc:
                    if exc.code in (301, 302, 303, 307, 308) and exc.headers.get("Location"):
                        url = urllib.parse.urljoin(url, exc.headers["Location"])
                        exc.close()
                        continue
                    code = exc.code
                    exc.close()
                    raise PluginError(f"下载失败 HTTP {code}；任务 {task_id} 已保存，可取回原结果") from None
                with response, open(partial, "wb") as target:
                    count = 0
                    expected = response.headers.get("Content-Length")
                    first = True
                    while True:
                        if time.monotonic() > deadline:
                            raise PluginError("下载超时，任务已保存，可稍后取回")
                        chunk = response.read(1024 * 1024)
                        if not chunk:
                            break
                        if first and (len(chunk) < 12 or chunk[4:8] != b"ftyp"):
                            raise PluginError("返回内容不是有效 MP4 文件，未写入分镜")
                        first = False
                        target.write(chunk)
                        count += len(chunk)
                    if not count or (expected and count != int(expected)):
                        raise PluginError("视频下载不完整，任务已保留")
                    target.flush()
                    os.fsync(target.fileno())
                os.replace(partial, output)
                return str(output)
            raise PluginError("下载重定向次数过多")
        finally:
            if os.path.exists(partial):
                os.unlink(partial)


@contextlib.contextmanager
def database():
    STATE_DIR.mkdir(parents=True, exist_ok=True)
    db = sqlite3.connect(str(STATE_DIR / "tasks.sqlite3"), timeout=30)
    db.row_factory = sqlite3.Row
    db.execute("CREATE TABLE IF NOT EXISTS tasks (local_id TEXT PRIMARY KEY, scope TEXT, slot TEXT, fingerprint TEXT, task_id TEXT, state TEXT, output TEXT, model TEXT, message TEXT, updated REAL)")
    try:
        yield db
        db.commit()
    finally:
        db.close()


def update(local_id, **values):
    allowed = {"task_id", "state", "message", "output"}
    if not set(values) <= allowed:
        raise ValueError("Invalid state update")
    values["updated"] = time.time()
    with database() as db:
        db.execute("UPDATE tasks SET " + ",".join(k + "=?" for k in values) + " WHERE local_id=?", list(values.values()) + [local_id])


@contextlib.contextmanager
def task_lock(identity):
    STATE_DIR.mkdir(parents=True, exist_ok=True)
    handle = open(STATE_DIR / (hashlib.sha256(identity.encode()).hexdigest() + ".lock"), "a+b")
    handle.seek(0)
    locked = False
    try:
        try:
            if os.name == "nt":
                import msvcrt
                msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            locked = True
        except OSError:
            raise PluginError("这个任务正在执行，请勿重复点击") from None
        if os.fstat(handle.fileno()).st_size == 0:
            handle.write(b"0")
            handle.flush()
        yield
    finally:
        if locked:
            handle.seek(0)
            if os.name == "nt":
                import msvcrt
                msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                import fcntl
                fcntl.flock(handle.fileno(), fcntl.LOCK_UN)
        handle.close()


def ordered(value):
    if not value:
        return []
    if isinstance(value, dict):
        if "参考图片MAP" in value:
            return ordered(value["参考图片MAP"])
        keys = sorted(value, key=lambda k: (0, int(k)) if str(k).isdigit() else (1, str(k)))
        return [value[k] for k in keys]
    if isinstance(value, (list, tuple)):
        return list(value)
    raise PluginError("宿主参考素材结构不受支持")


def prepare(context, params):
    model = str(params.get("model", "")).strip()
    prompt = str(context.get("prompt", "")).strip()
    if not model or not prompt:
        raise PluginError("请选择视频模型，并填写分镜视频提示词")
    payload = {"model": model, "prompt": prompt}
    values = special_values(params)
    if values:
        payload['model_parameters'] = values
    if str(params.get("seconds", "")).strip():
        payload["seconds"] = bounded(params["seconds"], 1, 3600, "时长")
    for field in ("ratio", "resolution"):
        if str(params.get(field, "")).strip():
            payload[field] = str(params[field]).strip()
    mode = params.get("input_mode", "references")
    if mode not in ("references", "text", "first", "frames"):
        raise PluginError("不支持的参考模式")
    refs = context.get("reference_images") or {}
    first = context.get("first_frame_path") or (refs.get("首帧") if isinstance(refs, dict) else None)
    end = context.get("end_frame_path") or (refs.get("尾帧") if isinstance(refs, dict) else None)
    if mode == "references" and (first or end):
        raise PluginError("此分镜设置了首尾帧，请选择“独立首尾帧”，或清除首尾帧后使用普通参考素材")
    if mode == "first" and (not first or end):
        raise PluginError("首帧模式需要一张首帧图；暂不支持尾帧角色映射")
    groups = {"image": ordered(refs), "video": ordered(context.get("reference_videos")), "audio": ordered(context.get("reference_audios"))} if mode == "references" else {"image": [first] if mode == "first" else [], "video": [], "audio": []}
    media = {kind: [] for kind in groups}
    signatures = []
    if mode == 'frames':
        if not first and not end:
            raise PluginError('请先在分镜中设置首帧或尾帧图片')
        for name, source in (('first_frame_url', first), ('last_frame_url', end)):
            if not source: continue
            source = str(source)
            if source.startswith(('https://', 'http://')):
                payload[name] = source
                signatures.append([name, source])
            else:
                file = Path(source).resolve()
                mime = mimetypes.guess_type(str(file))[0] or ''
                if not file.is_file() or not 0 < file.stat().st_size <= 20 * 1024 * 1024 or not mime.startswith('image/'):
                    raise PluginError('首尾帧必须是有效图片，每张不超过 20 MB')
                payload[name] = 'data:' + mime + ';base64,' + base64.b64encode(file.read_bytes()).decode('ascii')
                signatures.append([name, str(file), file.stat().st_size, file.stat().st_mtime_ns])
    for kind, items in groups.items():
        urls, seen_remote = [], False
        for item in items:
            if not isinstance(item, (str, os.PathLike)) or not str(item):
                raise PluginError("参考素材必须是路径或 URL")
            path = str(item)
            if path.startswith(("http://", "https://")):
                urls.append(path)
                seen_remote = True
                signatures.append(path)
            else:
                file = Path(path).resolve()
                if not file.is_file() or file.stat().st_size == 0:
                    raise PluginError(f"参考素材不存在或为空：{file.name}")
                media[kind].append(str(file))
                signatures.append([str(file), file.stat().st_size, file.stat().st_mtime_ns])
        # Server appends uploaded files after URL references, so mixed sources can reorder labels.
        if seen_remote and media[kind]:
            raise PluginError("同类参考素材请全部使用本地文件，或全部使用 URL，避免网站重排参考编号")
        if urls:
            payload[kind + "_urls"] = urls
    return payload, media, signatures


def notify(callback, text, progress=None):
    if callback:
        callback(text, progress)


def consume(client, row, body, callback=None):
    task_id, local_id = row["task_id"], row["local_id"]
    status = str(body.get("status", "")).lower()
    if status == "failed":
        message = redact(reason(body), client.key)
        update(local_id, state="failed", message=message)
        raise PluginError(f"任务 {task_id} 失败：{message}")
    if status == "completed":
        update(local_id, state="completed", message="生成完成，准备下载")
        notify(callback, "下载中", 100)
        path = client.download(task_id, row["output"])
        update(local_id, state="downloaded", message="已保存到作品目录")
        return path
    text = "待核实，继续查询原任务" if body.get("requires_review") else {"queued": "排队中", "processing": "生成中", "in_progress": "生成中"}.get(status, "未知状态，保留原任务继续查询")
    if body.get("queue_position"):
        text += f"（第 {body['queue_position']} 位）"
    update(local_id, state="pending", message=redact(body.get("message") or text, client.key))
    percent = body.get("progress")
    notify(callback, text, max(0, min(100, int(percent))) if isinstance(percent, (int, float)) and math.isfinite(percent) else None)
    return None


def poll(client, row, params, callback=None, initial=None):
    minutes = bounded(params.get("wait_minutes", 45), 1, 240, "等待分钟数")
    interval = bounded(params.get("poll_interval", 5), 2, 120, "查询间隔")
    deadline = time.monotonic() + minutes * 60
    body = initial
    while time.monotonic() < deadline:
        if body is None:
            try:
                body = client.query(row["task_id"])
            except PluginError as exc:
                update(row["local_id"], message=str(exc))
                notify(callback, "查询暂时异常，保留原任务")
                time.sleep(min(interval, max(0, deadline - time.monotonic())))
                continue
        result = consume(client, row, body, callback)
        if result:
            return result
        retry = body.get("retry_after", interval)
        try:
            delay = max(interval, float(retry))
            if not math.isfinite(delay):
                delay = interval
        except (ValueError, TypeError):
            delay = interval
        time.sleep(min(delay, max(0, deadline - time.monotonic())))
        body = None
    raise PluginError(f"等待达到上限，任务 {row['task_id']} 已保留。到插件“任务记录”查询并取回；不会自动重新生成")


def _generate(context):
    params = {**DEFAULTS, **(context.get("plugin_params") or get_params())}
    client = None
    try:
        client = Client(params)
        project = Path(context["project_path"]).resolve()
        if not project.is_dir():
            raise PluginError("作品目录不存在")
        unique = str(context["unique_name"])
        if not re.fullmatch(r"[\w-]+", unique):
            raise PluginError("分镜标识包含非法文件名字符")
        positions = context.get("output_position")
        if not isinstance(positions, list) or not positions:
            raise PluginError("宿主未提供输出槽位")
        payload, media, signatures = prepare(context, params)
        fingerprint = hashlib.sha256(json.dumps([payload, signatures], sort_keys=True, ensure_ascii=False).encode()).hexdigest()
        results = []
        for position in positions:
            name = f"{int(context['viewer_index']):04d}_{unique}_{int(context['generation_round'])}_{int(position)}.mp4"
            output = project / name
            slot = str(output)
            local_id = hashlib.sha256((client.scope + "\0" + slot).encode()).hexdigest()
            with task_lock(slot):
                with database() as db:
                    existing = db.execute("SELECT * FROM tasks WHERE local_id=?", (local_id,)).fetchone()
                    row = dict(existing) if existing else None
                if row:
                    if row["fingerprint"] != fingerprint:
                        raise PluginError("这个分镜槽位已有另一组参数的任务，请从任务记录取回，或使用新生成轮次")
                    if row["state"] == "downloaded" and output.is_file() and output.stat().st_size:
                        results.append(str(output))
                        continue
                    if row["state"] == "failed":
                        raise PluginError("此任务已明确失败：" + row["message"] + "。需要重新生成时请创建新轮次")
                    if not row["task_id"]:
                        raise PluginError("上次提交结果尚未确认，已阻止重复提交。请在网站调用记录核对，再在插件任务记录绑定原任务编号")
                    initial = None
                else:
                    notify(context.get("progress_callback"), "正在同步并核对网站模型")
                    validate_live_model(params, client, payload, media)
                    row = dict(local_id=local_id, scope=client.scope, slot=slot, fingerprint=fingerprint,
                               task_id="", state="submitting", output=str(output), model=payload["model"], message="正在提交", updated=time.time())
                    with database() as db:
                        db.execute("INSERT INTO tasks VALUES (?,?,?,?,?,?,?,?,?,?)", list(row.values()))
                    notify(context.get("progress_callback"), "提交中")
                    try:
                        initial = client.submit(payload, media)
                        task_id = initial.get("task_id") or initial.get("id")
                        if not isinstance(task_id, str) or not task_id.strip():
                            raise PluginError("网站未返回任务编号：" + reason(initial))
                        row["task_id"] = task_id
                        update(local_id, task_id=task_id, state="pending", message="已保存任务编号")
                    except Exception as exc:
                        message = redact(str(exc), client.key)
                        rejected = isinstance(exc, ApiError) and exc.status in (400, 401, 402, 403, 404, 409, 413, 415, 422)
                        update(local_id, state="failed" if rejected else "unknown", message=message)
                        suffix = "。网站拒绝了请求，请修正设置后使用新生成轮次" if rejected else "。未自动重发；请先到网站核对是否创建任务"
                        raise PluginError(message + suffix) from None
                results.append(poll(client, row, params, context.get("progress_callback"), initial))
        return results
    except Exception as exc:
        raise Exception("PLUGIN_ERROR:::" + redact(str(exc), client.key if client else str(params.get("api_key", "")))) from None


def _handle_action(action, data=None):
    data = data or {}
    params = {**get_params(), **data.get("params", {})}
    client = None
    try:
        if action == 'check_update':
            return updater.check(PLUGIN_ROOT, STATE_DIR, VERSION, manual=data.get('manual') is True)
        if action == 'install_update':
            return updater.install(PLUGIN_ROOT, STATE_DIR, VERSION, data.get('version'))
        if action == 'rollback_update':
            return updater.rollback(PLUGIN_ROOT, STATE_DIR)
        client = Client(params)
        if action == "catalog":
            return read_catalog(client)
        if action == "balance":
            return {"ok": True, "data": client.request("GET", "/billing/balance")}
        if action == "tasks":
            with database() as db:
                rows = [dict(r) for r in db.execute("SELECT local_id,task_id,state,model,message,output,updated FROM tasks WHERE scope=? ORDER BY updated DESC LIMIT 100", (client.scope,))]
            return {"ok": True, "tasks": rows}
        if action in ("recover", "bind"):
            with database() as db:
                record = db.execute("SELECT * FROM tasks WHERE local_id=? AND scope=?", (str(data.get("local_id", "")), client.scope)).fetchone()
            if not record:
                raise PluginError("任务记录不存在，或当前网站/API Key 与创建时不同")
            row = dict(record)
            with task_lock(row["slot"]):
                if action == "bind":
                    if row["task_id"]:
                        raise PluginError("此记录已有任务编号，无需绑定")
                    task_id = str(data.get("task_id", "")).strip()
                    if not re.fullmatch(r"task_[0-9]+", task_id):
                        raise PluginError("请填写网站调用记录中的 task_数字 编号")
                    body = client.query(task_id)
                    if body.get("id") != task_id and body.get("task_id") != task_id:
                        raise PluginError("网站返回的任务编号不匹配")
                    if body.get("model") and body["model"] != row["model"]:
                        raise PluginError("网站任务模型不匹配，未绑定")
                    update(row["local_id"], task_id=task_id, state="pending", message="已手动绑定原任务")
                    return {"ok": True, "message": "已绑定，请点击查询并取回"}
                if not row["task_id"]:
                    raise PluginError("无任务编号，请先核对网站记录并绑定")
                if not Path(row["output"]).parent.is_dir():
                    raise PluginError("原作品目录不存在，请先恢复作品目录")
                result = consume(client, row, client.query(row["task_id"]))
                return {"ok": True, "message": "已取回：" + result + "。请在作品中使用“找回未记录的生成结果”" if result else "任务仍在处理中，稍后再次查询"}
        raise PluginError("未知动作")
    except Exception as exc:
        return {"ok": False, "error": redact(str(exc), client.key if client else str(params.get("api_key", "")))}


def generate(context):
    try:
        with updater.activity(PLUGIN_ROOT, STATE_DIR, VERSION):
            return _generate(context)
    except updater.UpdateError as exc:
        raise Exception('PLUGIN_ERROR:::' + str(exc)) from None


def handle_action(action, data=None):
    if action not in ('recover', 'bind'):
        return _handle_action(action, data)
    try:
        with updater.activity(PLUGIN_ROOT, STATE_DIR, VERSION):
            return _handle_action(action, data)
    except updater.UpdateError as exc:
        return {'ok': False, 'error': str(exc)}
